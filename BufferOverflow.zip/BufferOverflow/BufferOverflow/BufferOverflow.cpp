// Maya Ellison
// SNHU CS405
// 5/14/23
// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	//Cannot change
	const std::string account_number = "CharlieBrown42";
	char user_input[20];


	//Declare how many variables array can hold
	const int max_input = 20;
	//Convert user input into string
	std::string input;

	//Get user input
	std::cout << "Enter a value: ";
	std::cin >> input;

	//If the input size is 19 or less (since last character must be null)
	if (input.size() <= max_input - 1) {
		//Use strncpy_s to copy input(string) with no more than 20 characters to array and does not copy those followed by
		// a null character
		strncpy_s(user_input, input.c_str(), sizeof(user_input));

		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
	else {
		//Input is to large, BufferOverflow
		std::cout << "ERROR BUFFER OVERFLOW" << std::endl;
	}
	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
