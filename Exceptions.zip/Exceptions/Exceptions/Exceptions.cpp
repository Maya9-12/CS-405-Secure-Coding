// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


bool do_even_more_custom_application_logic()
{
    //Throw a runtime error
    throw std::runtime_error("Error during runtime");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

//Define custom exception
struct customException : public std::exception {
    const char* what() const throw () {
        return "Custom exception.";
    }
};

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception
    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {      
         //displays a message and use exception.what() to continue processing
        std::cout << "Exception caught" << std::endl;
        std::cout << e.what() << std::endl;
    }
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw customException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    //Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0) {
        throw std::invalid_argument("Division by zero condition!");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    //create an exception handler to capture ONLY the exception thrown by divide

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& i) {
        //Display error message and use exception.what() to continue processing
        std::cout << "Division Error: " << i.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
        do_custom_application_logic();
    }
    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    catch (const customException& c) {
        //Display exception error message
        std::cout << "Custom exception caught" << std::endl;
    }
    //  std::exception
    catch (const std::exception& e) {
        //Display exception error message
        std::cout << "Standard exception caught" << std::endl;
    }  
    //  uncaught exception 
    catch (...) {
        //Display exception error message
        std::cout << "Other exception caught" << std::endl;
    }
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
